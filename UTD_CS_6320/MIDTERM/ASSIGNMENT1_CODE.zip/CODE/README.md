NAME : ROHITH PEDDI
NET ID : RXP190007
EMAIL : rxp190007@utdallas.edu
DETAILS : CS 6364 HW1


Submission consists of the following files :

1. Hw1_P2.py [Code for Problem 2]
2. Hw1_P3.py [Code for Problem 3]
3. search.py [Copied from AIMA repository]
4. utils.py [Copied from AIMA repository]
5. search_modified.py [Modified search methods of AIMA]

Place all the above files in a single directory. 

Documentation of code is included as part of the submission (File : HW1.pdf).

To see the output for Problem 2. 

Run file Hw1_P2.py

To see the output for Problem 3. 

Run file Hw1_P3.py